duplicity.backends.imapbackend module
=====================================

.. automodule:: duplicity.backends.imapbackend
   :members:
   :undoc-members:
   :show-inheritance:
