duplicity.progress module
=========================

.. automodule:: duplicity.progress
   :members:
   :undoc-members:
   :show-inheritance:
