duplicity.tempdir module
========================

.. automodule:: duplicity.tempdir
   :members:
   :undoc-members:
   :show-inheritance:
