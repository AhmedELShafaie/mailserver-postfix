duplicity.backends.mediafirebackend module
==========================================

.. automodule:: duplicity.backends.mediafirebackend
   :members:
   :undoc-members:
   :show-inheritance:
