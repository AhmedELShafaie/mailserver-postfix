duplicity.dup\_main module
==========================

.. automodule:: duplicity.dup_main
   :members:
   :undoc-members:
   :show-inheritance:
