testing.unit.test\_selection module
===================================

.. automodule:: testing.unit.test_selection
   :members:
   :undoc-members:
   :show-inheritance:
