duplicity.backends.localbackend module
======================================

.. automodule:: duplicity.backends.localbackend
   :members:
   :undoc-members:
   :show-inheritance:
