duplicity.backends.hsibackend module
====================================

.. automodule:: duplicity.backends.hsibackend
   :members:
   :undoc-members:
   :show-inheritance:
