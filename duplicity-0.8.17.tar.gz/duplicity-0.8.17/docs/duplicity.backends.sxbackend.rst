duplicity.backends.sxbackend module
===================================

.. automodule:: duplicity.backends.sxbackend
   :members:
   :undoc-members:
   :show-inheritance:
