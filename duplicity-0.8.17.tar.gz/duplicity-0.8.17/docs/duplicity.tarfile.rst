duplicity.tarfile module
========================

.. automodule:: duplicity.tarfile
   :members:
   :undoc-members:
   :show-inheritance:
