duplicity.selection module
==========================

.. automodule:: duplicity.selection
   :members:
   :undoc-members:
   :show-inheritance:
