testing.overrides.gettext module
================================

.. automodule:: testing.overrides.gettext
   :members:
   :undoc-members:
   :show-inheritance:
