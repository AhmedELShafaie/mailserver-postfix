testing.unit.test\_manifest module
==================================

.. automodule:: testing.unit.test_manifest
   :members:
   :undoc-members:
   :show-inheritance:
