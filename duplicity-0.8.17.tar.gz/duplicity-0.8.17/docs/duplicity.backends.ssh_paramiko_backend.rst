duplicity.backends.ssh\_paramiko\_backend module
================================================

.. automodule:: duplicity.backends.ssh_paramiko_backend
   :members:
   :undoc-members:
   :show-inheritance:
