duplicity.backends.s3\_boto\_backend module
===========================================

.. automodule:: duplicity.backends.s3_boto_backend
   :members:
   :undoc-members:
   :show-inheritance:
