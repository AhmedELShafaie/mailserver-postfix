duplicity.dup\_collections module
=================================

.. automodule:: duplicity.dup_collections
   :members:
   :undoc-members:
   :show-inheritance:
