duplicity.backends.ssh\_pexpect\_backend module
===============================================

.. automodule:: duplicity.backends.ssh_pexpect_backend
   :members:
   :undoc-members:
   :show-inheritance:
