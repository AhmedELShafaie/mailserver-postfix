duplicity.globmatch module
==========================

.. automodule:: duplicity.globmatch
   :members:
   :undoc-members:
   :show-inheritance:
