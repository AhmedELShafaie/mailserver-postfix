duplicity.backends.rsyncbackend module
======================================

.. automodule:: duplicity.backends.rsyncbackend
   :members:
   :undoc-members:
   :show-inheritance:
