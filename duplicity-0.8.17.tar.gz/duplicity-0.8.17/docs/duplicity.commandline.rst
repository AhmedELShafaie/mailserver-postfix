duplicity.commandline module
============================

.. automodule:: duplicity.commandline
   :members:
   :undoc-members:
   :show-inheritance:
