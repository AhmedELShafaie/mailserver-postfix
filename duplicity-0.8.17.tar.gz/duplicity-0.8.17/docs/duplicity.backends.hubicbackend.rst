duplicity.backends.hubicbackend module
======================================

.. automodule:: duplicity.backends.hubicbackend
   :members:
   :undoc-members:
   :show-inheritance:
