testing.functional.test\_selection module
=========================================

.. automodule:: testing.functional.test_selection
   :members:
   :undoc-members:
   :show-inheritance:
