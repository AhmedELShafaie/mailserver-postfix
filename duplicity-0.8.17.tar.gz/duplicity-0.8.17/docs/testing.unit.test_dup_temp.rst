testing.unit.test\_dup\_temp module
===================================

.. automodule:: testing.unit.test_dup_temp
   :members:
   :undoc-members:
   :show-inheritance:
