duplicity-git
=============

.. toctree::
   :maxdepth: 4

   duplicity
   setup
   testing
