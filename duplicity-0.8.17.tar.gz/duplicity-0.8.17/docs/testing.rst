testing package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   testing.functional
   testing.manual
   testing.overrides
   testing.unit

Submodules
----------

.. toctree::
   :maxdepth: 4

   testing.conftest
   testing.find_unadorned_strings
   testing.fix_unadorned_strings
   testing.test_code

Module contents
---------------

.. automodule:: testing
   :members:
   :undoc-members:
   :show-inheritance:
