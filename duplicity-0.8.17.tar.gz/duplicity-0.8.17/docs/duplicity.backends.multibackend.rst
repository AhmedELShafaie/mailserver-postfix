duplicity.backends.multibackend module
======================================

.. automodule:: duplicity.backends.multibackend
   :members:
   :undoc-members:
   :show-inheritance:
