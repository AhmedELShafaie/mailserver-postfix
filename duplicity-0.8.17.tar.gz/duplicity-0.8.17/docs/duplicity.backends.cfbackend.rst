duplicity.backends.cfbackend module
===================================

.. automodule:: duplicity.backends.cfbackend
   :members:
   :undoc-members:
   :show-inheritance:
