duplicity.backends package
==========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   duplicity.backends.pyrax_identity

Submodules
----------

.. toctree::
   :maxdepth: 4

   duplicity.backends.adbackend
   duplicity.backends.azurebackend
   duplicity.backends.b2backend
   duplicity.backends.cfbackend
   duplicity.backends.dpbxbackend
   duplicity.backends.gdocsbackend
   duplicity.backends.giobackend
   duplicity.backends.hsibackend
   duplicity.backends.hubicbackend
   duplicity.backends.imapbackend
   duplicity.backends.jottacloudbackend
   duplicity.backends.lftpbackend
   duplicity.backends.localbackend
   duplicity.backends.mediafirebackend
   duplicity.backends.megabackend
   duplicity.backends.megav2backend
   duplicity.backends.multibackend
   duplicity.backends.ncftpbackend
   duplicity.backends.onedrivebackend
   duplicity.backends.par2backend
   duplicity.backends.pcabackend
   duplicity.backends.pydrivebackend
   duplicity.backends.rclonebackend
   duplicity.backends.rsyncbackend
   duplicity.backends.s3_boto3_backend
   duplicity.backends.s3_boto_backend
   duplicity.backends.ssh_paramiko_backend
   duplicity.backends.ssh_pexpect_backend
   duplicity.backends.swiftbackend
   duplicity.backends.sxbackend
   duplicity.backends.tahoebackend
   duplicity.backends.webdavbackend

Module contents
---------------

.. automodule:: duplicity.backends
   :members:
   :undoc-members:
   :show-inheritance:
