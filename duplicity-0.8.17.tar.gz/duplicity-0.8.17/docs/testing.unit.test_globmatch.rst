testing.unit.test\_globmatch module
===================================

.. automodule:: testing.unit.test_globmatch
   :members:
   :undoc-members:
   :show-inheritance:
