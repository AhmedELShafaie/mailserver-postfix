duplicity.backends.pydrivebackend module
========================================

.. automodule:: duplicity.backends.pydrivebackend
   :members:
   :undoc-members:
   :show-inheritance:
