duplicity.gpg module
====================

.. automodule:: duplicity.gpg
   :members:
   :undoc-members:
   :show-inheritance:
