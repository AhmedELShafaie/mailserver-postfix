duplicity.backends.par2backend module
=====================================

.. automodule:: duplicity.backends.par2backend
   :members:
   :undoc-members:
   :show-inheritance:
