duplicity.config module
=======================

.. automodule:: duplicity.config
   :members:
   :undoc-members:
   :show-inheritance:
