duplicity.lazy module
=====================

.. automodule:: duplicity.lazy
   :members:
   :undoc-members:
   :show-inheritance:
