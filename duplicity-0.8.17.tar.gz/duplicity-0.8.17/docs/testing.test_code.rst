testing.test\_code module
=========================

.. automodule:: testing.test_code
   :members:
   :undoc-members:
   :show-inheritance:
