duplicity.backends.lftpbackend module
=====================================

.. automodule:: duplicity.backends.lftpbackend
   :members:
   :undoc-members:
   :show-inheritance:
