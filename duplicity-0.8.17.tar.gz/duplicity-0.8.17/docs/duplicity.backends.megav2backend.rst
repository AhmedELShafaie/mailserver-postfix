duplicity.backends.megav2backend module
=======================================

.. automodule:: duplicity.backends.megav2backend
   :members:
   :undoc-members:
   :show-inheritance:
