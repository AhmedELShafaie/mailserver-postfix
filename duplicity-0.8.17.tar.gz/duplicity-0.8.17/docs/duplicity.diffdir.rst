duplicity.diffdir module
========================

.. automodule:: duplicity.diffdir
   :members:
   :undoc-members:
   :show-inheritance:
