testing.unit.test\_lazy module
==============================

.. automodule:: testing.unit.test_lazy
   :members:
   :undoc-members:
   :show-inheritance:
