duplicity.backends.giobackend module
====================================

.. automodule:: duplicity.backends.giobackend
   :members:
   :undoc-members:
   :show-inheritance:
