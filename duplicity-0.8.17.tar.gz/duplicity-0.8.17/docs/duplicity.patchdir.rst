duplicity.patchdir module
=========================

.. automodule:: duplicity.patchdir
   :members:
   :undoc-members:
   :show-inheritance:
