duplicity.util module
=====================

.. automodule:: duplicity.util
   :members:
   :undoc-members:
   :show-inheritance:
