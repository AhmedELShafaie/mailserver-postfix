duplicity.manifest module
=========================

.. automodule:: duplicity.manifest
   :members:
   :undoc-members:
   :show-inheritance:
