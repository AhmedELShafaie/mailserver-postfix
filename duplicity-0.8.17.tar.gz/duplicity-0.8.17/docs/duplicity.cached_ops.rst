duplicity.cached\_ops module
============================

.. automodule:: duplicity.cached_ops
   :members:
   :undoc-members:
   :show-inheritance:
