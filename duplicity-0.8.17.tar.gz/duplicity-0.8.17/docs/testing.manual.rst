testing.manual package
======================

Submodules
----------

.. toctree::
   :maxdepth: 4

   testing.manual.backendtest
   testing.manual.roottest

Module contents
---------------

.. automodule:: testing.manual
   :members:
   :undoc-members:
   :show-inheritance:
