duplicity.collections module
============================

.. automodule:: duplicity.collections
    :members:
    :undoc-members:
    :show-inheritance:
