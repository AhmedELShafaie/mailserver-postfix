testing.functional.test\_final module
=====================================

.. automodule:: testing.functional.test_final
   :members:
   :undoc-members:
   :show-inheritance:
