testing.functional.test\_rdiffdir module
========================================

.. automodule:: testing.functional.test_rdiffdir
   :members:
   :undoc-members:
   :show-inheritance:
