duplicity.backends.megabackend module
=====================================

.. automodule:: duplicity.backends.megabackend
   :members:
   :undoc-members:
   :show-inheritance:
