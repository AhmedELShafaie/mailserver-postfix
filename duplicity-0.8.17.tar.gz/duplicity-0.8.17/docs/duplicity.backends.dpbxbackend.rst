duplicity.backends.dpbxbackend module
=====================================

.. automodule:: duplicity.backends.dpbxbackend
   :members:
   :undoc-members:
   :show-inheritance:
