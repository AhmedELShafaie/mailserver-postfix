testing.unit.test\_file\_naming module
======================================

.. automodule:: testing.unit.test_file_naming
   :members:
   :undoc-members:
   :show-inheritance:
