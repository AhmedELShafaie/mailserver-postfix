duplicity.statistics module
===========================

.. automodule:: duplicity.statistics
   :members:
   :undoc-members:
   :show-inheritance:
