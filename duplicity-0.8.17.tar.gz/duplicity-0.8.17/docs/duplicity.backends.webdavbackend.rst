duplicity.backends.webdavbackend module
=======================================

.. automodule:: duplicity.backends.webdavbackend
   :members:
   :undoc-members:
   :show-inheritance:
