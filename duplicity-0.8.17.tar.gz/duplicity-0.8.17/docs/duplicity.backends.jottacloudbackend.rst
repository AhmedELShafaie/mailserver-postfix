duplicity.backends.jottacloudbackend module
===========================================

.. automodule:: duplicity.backends.jottacloudbackend
   :members:
   :undoc-members:
   :show-inheritance:
