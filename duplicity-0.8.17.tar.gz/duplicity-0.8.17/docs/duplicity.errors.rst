duplicity.errors module
=======================

.. automodule:: duplicity.errors
   :members:
   :undoc-members:
   :show-inheritance:
