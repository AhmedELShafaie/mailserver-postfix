duplicity.dup\_time module
==========================

.. automodule:: duplicity.dup_time
   :members:
   :undoc-members:
   :show-inheritance:
