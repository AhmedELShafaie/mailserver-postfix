duplicity.backends.s3\_boto3\_backend module
============================================

.. automodule:: duplicity.backends.s3_boto3_backend
   :members:
   :undoc-members:
   :show-inheritance:
