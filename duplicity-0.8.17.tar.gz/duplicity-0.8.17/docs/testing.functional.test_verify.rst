testing.functional.test\_verify module
======================================

.. automodule:: testing.functional.test_verify
   :members:
   :undoc-members:
   :show-inheritance:
