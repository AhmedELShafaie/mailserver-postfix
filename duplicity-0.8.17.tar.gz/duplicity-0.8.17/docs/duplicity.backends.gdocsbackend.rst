duplicity.backends.gdocsbackend module
======================================

.. automodule:: duplicity.backends.gdocsbackend
   :members:
   :undoc-members:
   :show-inheritance:
