duplicity.dup\_temp module
==========================

.. automodule:: duplicity.dup_temp
   :members:
   :undoc-members:
   :show-inheritance:
