duplicity.log module
====================

.. automodule:: duplicity.log
   :members:
   :undoc-members:
   :show-inheritance:
