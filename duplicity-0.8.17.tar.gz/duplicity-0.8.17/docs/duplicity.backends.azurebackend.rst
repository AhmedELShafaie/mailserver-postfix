duplicity.backends.azurebackend module
======================================

.. automodule:: duplicity.backends.azurebackend
   :members:
   :undoc-members:
   :show-inheritance:
