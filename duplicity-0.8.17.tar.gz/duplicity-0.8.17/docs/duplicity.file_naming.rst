duplicity.file\_naming module
=============================

.. automodule:: duplicity.file_naming
   :members:
   :undoc-members:
   :show-inheritance:
