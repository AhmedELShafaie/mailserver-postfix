testing.unit.test\_statistics module
====================================

.. automodule:: testing.unit.test_statistics
   :members:
   :undoc-members:
   :show-inheritance:
