duplicity.backends.swiftbackend module
======================================

.. automodule:: duplicity.backends.swiftbackend
   :members:
   :undoc-members:
   :show-inheritance:
