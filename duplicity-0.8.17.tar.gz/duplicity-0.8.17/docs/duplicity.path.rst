duplicity.path module
=====================

.. automodule:: duplicity.path
   :members:
   :undoc-members:
   :show-inheritance:
