duplicity.robust module
=======================

.. automodule:: duplicity.robust
   :members:
   :undoc-members:
   :show-inheritance:
