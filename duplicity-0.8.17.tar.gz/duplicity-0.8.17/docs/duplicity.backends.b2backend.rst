duplicity.backends.b2backend module
===================================

.. automodule:: duplicity.backends.b2backend
   :members:
   :undoc-members:
   :show-inheritance:
