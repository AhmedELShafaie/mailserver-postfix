duplicity.dup\_threading module
===============================

.. automodule:: duplicity.dup_threading
   :members:
   :undoc-members:
   :show-inheritance:
