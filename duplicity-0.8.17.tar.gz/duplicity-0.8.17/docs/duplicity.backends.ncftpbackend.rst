duplicity.backends.ncftpbackend module
======================================

.. automodule:: duplicity.backends.ncftpbackend
   :members:
   :undoc-members:
   :show-inheritance:
