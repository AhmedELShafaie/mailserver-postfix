testing.fix\_unadorned\_strings module
======================================

.. automodule:: testing.fix_unadorned_strings
   :members:
   :undoc-members:
   :show-inheritance:
