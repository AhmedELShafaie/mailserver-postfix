duplicity.backend module
========================

.. automodule:: duplicity.backend
   :members:
   :undoc-members:
   :show-inheritance:
