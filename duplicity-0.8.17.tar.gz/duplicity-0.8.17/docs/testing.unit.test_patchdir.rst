testing.unit.test\_patchdir module
==================================

.. automodule:: testing.unit.test_patchdir
   :members:
   :undoc-members:
   :show-inheritance:
