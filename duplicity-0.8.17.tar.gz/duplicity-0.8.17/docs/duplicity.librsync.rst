duplicity.librsync module
=========================

.. automodule:: duplicity.librsync
   :members:
   :undoc-members:
   :show-inheritance:
