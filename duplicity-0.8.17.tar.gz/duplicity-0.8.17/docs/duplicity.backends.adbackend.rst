duplicity.backends.adbackend module
===================================

.. automodule:: duplicity.backends.adbackend
   :members:
   :undoc-members:
   :show-inheritance:
