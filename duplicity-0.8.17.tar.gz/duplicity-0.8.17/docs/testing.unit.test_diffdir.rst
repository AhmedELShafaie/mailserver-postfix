testing.unit.test\_diffdir module
=================================

.. automodule:: testing.unit.test_diffdir
   :members:
   :undoc-members:
   :show-inheritance:
