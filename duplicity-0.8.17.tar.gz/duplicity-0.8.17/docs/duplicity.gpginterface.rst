duplicity.gpginterface module
=============================

.. automodule:: duplicity.gpginterface
   :members:
   :undoc-members:
   :show-inheritance:
