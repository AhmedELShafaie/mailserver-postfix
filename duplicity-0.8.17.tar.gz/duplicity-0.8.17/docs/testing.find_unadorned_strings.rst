testing.find\_unadorned\_strings module
=======================================

.. automodule:: testing.find_unadorned_strings
   :members:
   :undoc-members:
   :show-inheritance:
