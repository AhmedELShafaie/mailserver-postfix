duplicity.backends.pyrax\_identity.hubic module
===============================================

.. automodule:: duplicity.backends.pyrax_identity.hubic
   :members:
   :undoc-members:
   :show-inheritance:
