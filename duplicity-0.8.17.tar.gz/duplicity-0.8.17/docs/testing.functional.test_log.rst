testing.functional.test\_log module
===================================

.. automodule:: testing.functional.test_log
   :members:
   :undoc-members:
   :show-inheritance:
